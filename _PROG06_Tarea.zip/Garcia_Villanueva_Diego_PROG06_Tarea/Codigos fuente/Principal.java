//*Tarea unidad 6 del CFGS DAM 21/22 impartido en el CIDEAD.
//*Clase principal.
package PROG06_Ejerc1;

/**
 * @author Diego García Villanueva
 */
import java.util.Scanner;
import PROG06_Ejerc1_Util.Validar;
import java.util.InputMismatchException;

public class Principal {

    public static void main(String[] args) throws Exception {
        boolean salir = false;
        boolean datoCorrecto = false;
        int opcion = 0, kilometros = 0;
        String modelo, descripcion, matricula = null, propietario = null, dni = null;
        double precio = 0;
        Vehiculo v;

        //*Creacion del objeto "con" de la clase Concesionario.
        Concesionario con = new Concesionario();

        Scanner entrada = new Scanner(System.in);

        //*Todo el código principal esta en un bucle while, donde mientras no se escoja la opcion salir, el programa seguirá ejecutandose.
        while (!salir) {
            //*Captura de excepcion del tipo InputMismatchException, por si no se inserta un valor numérico.
            try {
                do {
                    System.out.println("ELIGE UNA OPCIÓN \n");
                    System.out.println("1. Nuevo vehículo");
                    System.out.println("2. Listar vehículo");
                    System.out.println("3. Buscar vehículo");
                    System.out.println("4. Modificar kms vehículo");
                    System.out.println("5. Salir");

                    opcion = entrada.nextInt();
                    entrada.nextLine();
                } while (opcion < 1 || opcion > 5);
            } catch (InputMismatchException e) {
                System.out.println("Debes introducir un valor numérico del 1 al 5\n");
                entrada.next();
            }
            switch (opcion) {

                case 1:
                    
                    //*Inserción del modelo.
                    System.out.println("¿Qué modelo de vehiculo es?");
                    modelo = entrada.nextLine();
                    System.out.println("Modelo guardado correctamente.\n");

                    /*Para la introducción correcta de la matricula, se usa un bucle while, 
                    mientras la matricula no tenga el formato correcto, la variable datoCorrecto no tendrá el valor true, 
                    por tanto el programa seguirá solicitando una matrícula hasta que esta sea válida. Este formato será usado en las demás opciones con pequeñas variaciones.*/
                    while (!datoCorrecto) {
                        System.out.println("¿Cuál es la matrícula del vehiculo?");
                        matricula = entrada.next();
                        if (!Validar.valMatricula(matricula)) {
                            System.out.println("El formato de la matricula no es correcto, vuelve a intentarlo.");
                        } else {
                            datoCorrecto = true;
                            System.out.println("Matrícula guardada correctamente \n");
                        }
                    }
                    //*Vuelvo a declarar la variable datoCorrecto como false para poder volver a usarla.
                    datoCorrecto = false;

                    /*Inserción de los kms. Se captura una excepción del tipo InputMismatchException por si introducen un valor distinto al tipo solicitado (int) 
                    y llamamos al método valKms por si se introduce un número negativo.*/
                    while (!datoCorrecto) {
                        try {
                            System.out.println("¿Cuántos kilómetros tiene el vehículo?");
                            kilometros = entrada.nextInt();
                            entrada.nextLine();
                            if (!Validar.valKms(kilometros)) {
                                System.out.println("Introduce un número de Km´s correcto.");
                            } else {
                                datoCorrecto = true;
                                System.out.println("Kilómetros guardados correctamente \n");
                            }
                        } catch (InputMismatchException e) {
                            System.out.println("Debes introducir un valor numérico, vuelve a intentarlo.\n");
                            entrada.next();
                        }
                    }
                    datoCorrecto = false;
                    
                    //*Inserción del nombre del propietario, se usa el método valNombre para la validación del nombre.
                    while (!datoCorrecto) {
                        System.out.println("¿Como se llama el propietario?");
                        propietario = entrada.nextLine();
                        if (!Validar.valNombre(propietario)) {
                            System.out.println("Formato de nombre no valido, vuelve a intenttarlo.\n");
                        } else {
                            datoCorrecto = true;
                            System.out.println("Nombre del propietario guardado correctamente.\n");
                        }
                    }

                    datoCorrecto = false;
                    
                    //*Inserción del dni, se usa el método valDni para la validación del dni.
                    while (!datoCorrecto) {
                        System.out.println("¿Cuál es el DNI del propietario?");
                        dni = entrada.next();
                        if (!Validar.valDni(dni)) {
                            System.out.println("El DNI no tiene el formato correcto, vuelve a intentearlo.");
                        } else {
                            datoCorrecto = true;
                            System.out.println("DNI guardado correctamente.\n");
                        }
                    }
                    datoCorrecto = false;

                    /*Inserción del precio. Se captura una excepción del tipo InputMismatchException por si introducen un valor distinto al tipo solicitado (double) 
                    y llamamos al método valPrecio por si se introduce un número negativo.*/
                    while (!datoCorrecto) {
                        try {
                            System.out.println("¿Cuál es el precio del vehículo?");
                            precio = entrada.nextDouble();
                            entrada.nextLine();
                            if (!Validar.valPrecio(precio)) {
                                System.out.println("El formato del precio no es correcto, vuelve a intentarlo.");
                            } else {
                                datoCorrecto = true;
                                System.out.println("Precio guardado correctamente.\n");
                            }
                        } catch (InputMismatchException e) {
                            System.out.println("Debes introducir un valor numérico, vuelve a intentarlo.");
                            entrada.next();
                        }
                    }
                    datoCorrecto = false;
                    
                    //*Inserción de la descripción del vehículo
                    System.out.println("Describre brevemente el estado del vehículo.");
                    descripcion = entrada.nextLine();
                    System.out.println("Descripción del vehículo guardada correctamente.\n");

                    //*Creacion del vehículo con los parametros introducidos, e inserción dentro del concesionario, usando el método insertarVehículo.
                    v = new Vehiculo(modelo, matricula, kilometros, propietario, dni, precio, descripcion);

                    switch (con.insertarVehiculo(v)) {
                        case 0:
                            System.out.println("Vehiculo guardado correctamente.\n");
                            break;
                        case -1:
                            System.out.println("No hay espacio en el concesionario para añadir mas vehículos.\n");
                            break;
                        case -2:
                            System.out.println("El vehículo con la matrícula indicada ya existe en el concesionario.\n");
                            break;
                    }
                    break;

                //*Se llama al método listaVehiculos, el cual nos imprime por pantalla los vehículos almacenados.
                case 2:
                    System.out.println("Esta es la lista de vehículos: \n");
                    con.listaVehiculos();
                    break;

                //*Llamada al método buscaVehiculo. 
                case 3:
                    System.out.println("Introduce una matrícula:");
                    matricula = entrada.next();

                    v = con.buscaVehiculo(matricula);
                    if (v != null) {
                        System.out.println("Modelo: " + v.getModelo());
                        System.out.println("Matrícula: " + v.getMatricula());
                        System.out.println("Precio: " + v.getPrecio());
                    } else {
                        System.out.println("no existe vehículo con la matrícula introducida.");
                    }
                    break;

                //*Modificar los Kms de un vehículo.Se pide la matrícula.
                case 4:
                    try {
                    System.out.println("Introduce la matrícula del vehículo que quieres actualizar:");
                    matricula = entrada.next();

                    /*Primero hago una llamada al método buscarVehículo,de esta forma, si no hay un vehiculo con la matrícula insertada, el programa no sigue. 
                    Se puede poner solo el método actualizaKms, pero con este si se inserta una matrícula erronea, se piden los kms igual,
                    y nos dará el mensaje de matricula no encontrada despues.*/
                    //*Los kms deben ser actualizados con una cantidad superior a la que tienen.
                    v = con.buscaVehiculo(matricula);
                    if (v != null) {
                        System.out.println("Actualiza los kilómetros:");
                        kilometros = entrada.nextInt();
                        entrada.nextLine();
                        if (con.actualizaKms(matricula, kilometros)) {
                            System.out.println("Los kilometros han sido actualizados correctamente.");
                        } else {
                            System.out.println("Debes introducer un número de kms superior al anterior.");
                        }
                    } else {
                        System.out.println("La matricula introducida no corresponde a ningún vehículo.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Debes introducir un valor numérico, vuelve a intentarlo.");
                    entrada.next();
                }
                break;

                case 5:
                    salir = true;
                    break;
            }
        }
    }
}
