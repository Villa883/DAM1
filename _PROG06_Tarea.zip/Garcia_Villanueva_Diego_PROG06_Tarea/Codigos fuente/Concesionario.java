//*Tarea unidad 6 del CFGS DAM 21/22 impartido en el CIDEAD
//*Clase concesionario
package PROG06_Ejerc1;

/**
 * @author Diego García Villanueva
 */
public class Concesionario {

    private final int max = 50;
    private int numV = 0;

    //*Declaracion del array.
    Vehiculo[] v;

    //*Creación del constructor de la clase concesionario y creación del array.
    public Concesionario() {
        v = new Vehiculo[max];
    }

    /*Método para buscar un vehículo por su matrícula, con el bucle for se recorre el array, y continúo
    evaluando si se cumplen las condiciones de, si v[i] es diferente de null y si v[i].getMatricula() es igual a matricula, asi
    evito que el programa me genere una excepción del tipo java.lang.NullPointerException, pues de esta manera me aseguro de que el objeto v[i]existe. 
    En el caso de no encontrar una matricula igual nos retorna null*/
    public Vehiculo buscaVehiculo(String matricula) {
        for (int i = 0; i < max; i++) {
            if (v[i] != null && v[i].getMatricula().equals(matricula)) {
                return v[i];
            }
        }
        return null;
    }

    //*Método para la inserción de los objetos vehiculo dentro del array utilizando un atributo de tipo entero.
    /*Con el primer bucle for, se recorre el array y se busca si hay algún vehículo con la misma matrícula, en caso de encontrarla nos retorna -2. 
    Con el operador lógico && y la condición expresada, se evita la excepcion del tipo java.lang.NullPointerException, que se puede dar 
    al insertar el primer vehículo y no tener matrícula con que comparar(getMatricula tendría un valor null).*/
    /*En el segundo for se recorre el array en busaca de un espacio libre, si lo hay se almacena el vehículo y se retorna el código 0,
    en caso contrario significa que el array está lleno, y nos retornará -1*/
    public int insertarVehiculo(Vehiculo v1) {
        for (int i = 0; i < max; i++) {
            if (v[i] != null && v[i].getMatricula().equals(v1.getMatricula())) {
                return -2;
            }
        }
        for (int i = 0; i < v.length; i++) {
            if (v[i] == null) {
                v[i] = v1;
                numV++;

                return 0;
            }
        }
        return -1;
    }

    //*Método para listar por pantalla los datos de todos los vehiculos.
    //*El bucle for recorre el array hasta donde haya vehículos insertados e imprime por pantalla el método toString de la clase vehículo con los vehiculos creados.
    public void listaVehiculos() {
        for (int i = 0; i < numV; i++) {
            System.out.println(v[i].toString());
        }
    }

    //*Método para actualizar los kms.
    /*El bucle for recorre el array, se tienen que cumplir las tres condiciones, que el vehículo esté creado, que los kilómetros se actualicen al alza y que exista una matrícula como la insertada. 
    Si se cumplen las tres condiciones los kms son actualizados*/
    public boolean actualizaKms(String matricula, int kilometros) {
        for (int i = 0; i < max; i++) {
            if (v[i] != null && kilometros > v[i].getKilometros() && v[i].getMatricula().equals(matricula)) {
                v[i].setKilometros(kilometros);
                return true;
            }
        }
        return false;
    }
}
