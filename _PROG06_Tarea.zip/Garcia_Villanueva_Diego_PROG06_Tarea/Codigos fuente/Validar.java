//**Tarea unidad 6 del CFGS DAM 21/22 impartido en el CIDEAD
//*Clase con los métodos de validación necesarios. 
package PROG06_Ejerc1_Util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Diego García Villanueva
 */
public class Validar {

    //*Validacion de la matricula usando expresiones regulares.
    public static boolean valMatricula(String matricula) {
        Pattern p = Pattern.compile("[0-9]{4}[A-Z]{3}");
        Matcher m = p.matcher(matricula);
        return m.matches();
    }

    //*Validación de los kms, debe ser un número positivo(supongamos que un vehículo puede estar nuevo con cero kms).
    public static boolean valKms(int kms) {
        return kms >= 0;
    }

    //*Validación del DNI usando expresiones regulares.
    public static boolean valDni(String dni) {
        Pattern p = Pattern.compile("[0-9]{8}[A-Za-z]{1}");
        Matcher m = p.matcher(dni);
        return m.matches();
    }

    //*Validación del precio, debe ser una cifra positiva(Supongamos que puede haber vehículos con un precio bajo o incluso de cero).
    public static boolean valPrecio(double precio) {
        return precio >= 0;
    }

    /*Para la validación del nombre usaré el método split de la clase String.
    Con este método puedo dividir la cadena en varias partes tomando el espacio (" ") como separador, y creando un array con el nombre y apellidos,
    basta con ponerle un máximo y un minimo de palabras al array. El nombre será válido siempre que tenga tres palabras separadas por un espacio cada una.*/
    public static boolean valNombre(String propietario) {

        String[] nombres = propietario.split(" ");
        if (nombres.length < 3 || nombres.length > 3) {
            return false;
        }
        //*Longitud máxima de 40 caracteres.
        if (propietario.length() > 40) {
            return false;
        }
        return true;
    }
}
