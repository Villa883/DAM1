/*Tarea unidad 6 del CFGS DAM 21/22 impartido en el CIDEAD*/
 /*Clase para la creación del objeto vehículo*/
package PROG06_Ejerc1;

/**
 * @author Diego García Villanueva
 */
public class Vehiculo {

    private String modelo;
    private String matricula;
    private int kilometros;
    private String propietario;
    private String dni;
    private double precio;
    private String descripcion;

    /*Constructor vacio*/
    public Vehiculo() {
    }

    /*Construcctor con parámetros*/
    public Vehiculo(String modelo, String matricula, int kilometros, String propietario, String dni, double precio, String descripcion) {
        this.modelo = modelo;
        this.matricula = matricula;
        this.kilometros = kilometros;
        this.propietario = propietario;
        this.dni = dni;
        this.precio = precio;
        this.descripcion = descripcion;
    }

    /*Métodos get and set*/
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getKilometros() {
        return kilometros;
    }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    public String getPropietario() {
        return propietario;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    //*Método toString.
    @Override
    public String toString() {
        return "Modelo: " + modelo + " Matrícula: " + matricula + " Kilómetros: " + kilometros + " Propietario: " + propietario + " DNI: " + dni + " Precio: " + precio + " € " + "Descripcion: " + descripcion;
    }
}
